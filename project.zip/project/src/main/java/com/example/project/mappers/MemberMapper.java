package com.example.project.mappers;

import com.example.project.dto.MemberDto;
import com.example.project.dto.MessageDto;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface MemberMapper {
    //회원가입 저장
    @Insert("INSERT INTO member VALUES(NULL, #{memberEmail},#{memberPasswd},#{memberName}, '회원', now())")
    public void setMemberInfo(MemberDto mdto);

    //로그인
    @Select("SELECT * FROM member WHERE memberEmail=#{memberEmail} AND memberPasswd=#{memberPasswd}")
    public MemberDto loginCheck(MemberDto mdto);

    //메시지
    @Insert("INSERT INTO message VALUES(NULL,#{itemId},#{senderId},#{receiverId},#{msgContent}, CURRENT_TIMESTAMP)")
    public void setMessage(MessageDto msgDto);
}
